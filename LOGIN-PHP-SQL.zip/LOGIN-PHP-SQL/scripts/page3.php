<?php 
require_once __DIR__ . '/../inc/navbar.php';
?>

<div class="container nt-5">
    <div class="row">
        <div class="col">
            <hr>
            <h4>Page 3</h4>
            <p class="mt-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea illo autem ullam amet dolore minus consequatur quam quisquam eum eius? Rerum, quaerat vero tempora debitis voluptatem cupiditate eos fugiat ullam?
            Incidunt blanditiis voluptatum hic exercitationem possimus reiciendis? Eveniet, natus placeat ad, aut eaque fugiat dolores laudantium veritatis architecto enim voluptate aperiam sapiente nulla exercitationem soluta cum dolorem impedit pariatur est.
            Amet pariatur enim dolores consequatur ipsam corrupti qui eligendi quaerat, nam laboriosam iste provident possimus veritatis ea fuga repudiandae cupiditate iure maxime obcaecati, impedit sit fugiat officiis tempore! Minima, quis!
            Incidunt atque porro dicta eligendi voluptates libero deleniti itaque nulla eius ab sapiente, dolore accusantium hic culpa. Cumque laudantium, similique natus sapiente laborum dolore dicta iusto inventore, rerum omnis in.
            Ea quidem dicta asperiores rerum, corporis impedit excepturi sapiente aliquam cum atque nihil consequatur alias mollitia et pariatur facere dolorem voluptate vitae obcaecati possimus veniam at aperiam quam illum! Harum?
            Adipisci sed deserunt officia voluptates accusantium fugit quasi ipsam. Nesciunt, dolorum iure. Itaque architecto voluptates rerum ex dicta quo vero accusantium, totam laborum quam alias nemo sint iste temporibus iure.
            Magnam iste consectetur numquam earum magni soluta. Facere doloremque iste praesentium magni repudiandae, tenetur quis accusantium voluptatem earum ullam alias reiciendis harum, illo cupiditate cumque sequi aperiam molestiae maiores impedit?
            Aliquam temporibus ducimus soluta asperiores, magnam voluptatum nulla dolore saepe tempore officia dolorum aperiam adipisci pariatur enim accusamus, quaerat obcaecati, inventore consectetur ea ipsam ipsa! Accusantium doloremque provident ullam nisi.
            Ipsum perferendis similique dignissimos cupiditate cumque modi, libero corrupti! Odit maxime numquam necessitatibus error in esse consequuntur odio quae aperiam hic? Facilis, nulla? Fugiat alias suscipit magnam accusantium, reprehenderit sit.
            Modi distinctio ipsam debitis quisquam? Distinctio porro repudiandae eum corrupti repellat ad ab. Quod laudantium, veritatis culpa repellat similique mollitia delectus. Nesciunt quis animi dolores omnis reiciendis itaque ipsa dicta!
            Ad iste vitae iure assumenda consectetur fugiat dolorum quae repudiandae magnam! Dignissimos soluta, adipisci cum facere, consequatur, veritatis accusantium qui asperiores delectus minima culpa repellendus dolore inventore eos quaerat incidunt!
            Reiciendis at alias omnis repellat perspiciatis voluptatum, aliquid eius fugit labore dolore, quae iusto qui. Amet ex tempore molestias perspiciatis, distinctio alias rerum, laudantium iste esse corrupti iure quia aliquam.
            Eligendi eos, atque maiores, exercitationem aut officiis nam quos aspernatur quas, dolorum porro sint nobis veniam itaque iste ab! Tempora iusto nobis molestiae voluptates officia deleniti dolorum, natus quae assumenda?
            Labore, veniam maxime minima consequuntur consectetur magnam sed tenetur voluptatibus autem vero recusandae est, expedita voluptas dolor assumenda libero! Dolorum earum tempora consequuntur libero odit eum ipsam enim saepe! Nihil.
            Nemo ducimus nisi eaque laudantium neque rem eius ut, quas, distinctio, dolorum odit repellat. Voluptates deleniti dolore, laudantium porro ad error libero tempora. Nam ullam quibusdam reiciendis! Ad, nisi error?
            Asperiores quasi ex accusamus quaerat consectetur autem nisi maxime nostrum non, id beatae ipsam aperiam! Facere corrupti cupiditate, eos, voluptatibus iste deleniti impedit, nobis aut ullam odit quod in ipsam?
            Asperiores quasi repellendus, molestias enim amet aperiam maxime laudantium dolore dolorem ipsam nesciunt ab consectetur cumque neque quia maiores autem quae, distinctio incidunt iste adipisci minima voluptatibus voluptate quod. Omnis!
            Voluptatibus possimus inventore ex facere? Velit, possimus ut animi nostrum sunt reiciendis vitae nesciunt totam dicta fuga autem nihil asperiores illum, beatae sit ea dolore non deleniti ipsa blanditiis veniam.
            Tempore voluptates vel veniam alias. Sit quasi sequi quos dolore quisquam inventore, esse quia numquam, laborum, cupiditate officiis! Ea neque pariatur enim eius veritatis fuga quos sint assumenda ipsa ut.
            Perferendis, dolorem. Voluptates, eos dolore vitae rem cum tempore esse labore alias incidunt ad laudantium id aperiam quo, molestias aut quidem amet. Deserunt labore, commodi quibusdam numquam nam provident accusamus.
            Maxime accusamus ducimus recusandae praesentium eius velit excepturi delectus ex illo ea impedit libero perspiciatis nobis, sint aliquam mollitia! Voluptatum eum magnam veritatis ratione non veniam beatae labore, voluptatem inventore.
            Nam, nisi? Facere eligendi odit consequuntur debitis, natus provident magni adipisci repellendus quidem nulla. Esse in dolor autem vitae mollitia officiis alias natus ipsam eum repellat, quibusdam perferendis ut deleniti?
            Eligendi distinctio suscipit mollitia perspiciatis nihil exercitationem aliquid! Ad assumenda facilis recusandae fuga quod excepturi ea consequuntur. Vero beatae vel consequatur, hic a earum recusandae, modi ut, totam quae nesciunt.
            Quibusdam beatae cupiditate deserunt laborum, placeat numquam et excepturi culpa incidunt? At libero facere autem! Quaerat modi eligendi quam iusto blanditiis, sunt totam necessitatibus repellendus magni doloremque nulla. Excepturi, libero.
            Fugiat facilis, sapiente, id molestias quos deserunt suscipit culpa quia nobis laboriosam blanditiis vel consectetur ex velit nulla, eum sunt. Enim veniam reprehenderit aperiam pariatur aliquid culpa animi ab officiis.</p>
        </div>
    </div>
</div>