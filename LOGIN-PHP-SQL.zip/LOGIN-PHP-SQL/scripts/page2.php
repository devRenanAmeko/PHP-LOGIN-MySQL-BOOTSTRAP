<?php 
require_once __DIR__ . '/../inc/navbar.php';
?>

<div class="container nt-5">
    <div class="row">
        <div class="col">
            <hr>
            <h4>Page 2</h4>
            <p class="mt-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem magni autem distinctio dolorum dolore labore nostrum deserunt alias minus aspernatur. Quas mollitia voluptatum deserunt tempora ad laborum corporis fugiat fugit?
            Excepturi ducimus tempore fuga, inventore dolores, est consectetur itaque nulla aliquam doloremque veniam ipsam explicabo quidem, qui odio! In itaque, at non doloremque molestiae quasi aperiam libero incidunt recusandae accusantium?
            Neque eos repudiandae ea minima eius aliquam cumque explicabo autem dolore. Nobis perferendis neque, dolore commodi dolores molestias assumenda esse itaque quis eaque quia non cupiditate sapiente mollitia laborum suscipit?</p>
        </div>
    </div>
</div>