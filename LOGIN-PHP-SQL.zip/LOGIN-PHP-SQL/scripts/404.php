<div class="d-flex mt-5 justify-content-center">
    <h4>ERRO 404</h4>
    <p class="text-danger">Recursos não encontrados</p>
</div>