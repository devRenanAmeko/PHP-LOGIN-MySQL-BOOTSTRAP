<?php 
require_once __DIR__ . '/../inc/navbar.php';
?>

<div class="container nt-5">
    <div class="row">
        <div class="col">
            <hr>
            <h4>Page 1</h4>
            <p class="mt-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos vero architecto accusamus voluptas, delectus velit vel. Error, esse. Reprehenderit, officiis. Pariatur saepe doloribus ex aliquid perspiciatis totam asperiores minus aliquam!
            Aspernatur error ex, architecto aliquam, neque voluptate tenetur numquam atque aperiam omnis cupiditate veniam magnam exercitationem fuga perspiciatis corrupti saepe labore reiciendis. Corporis voluptatibus distinctio nihil excepturi similique accusantium? Fugiat.
            Et laudantium quibusdam, magni vitae ducimus fugiat deserunt quod repellendus vero natus, blanditiis voluptas facilis eum rerum inventore ullam molestiae obcaecati expedita perferendis aperiam ea necessitatibus commodi. Accusantium, cum tempore.
            Earum blanditiis harum eum similique quia laudantium nobis voluptatibus nihil illo. Veniam, possimus molestiae! Sint temporibus ex error sapiente, architecto, pariatur voluptates natus eveniet recusandae, in vitae nobis sed iure!
            Ex itaque illum harum a sunt deleniti eaque voluptatem ipsa reiciendis nulla aut minus nesciunt explicabo id, possimus fugiat enim ipsum quod. Distinctio iste nulla, obcaecati laborum corporis ipsam excepturi!
            Illum in voluptatum qui, ducimus nihil odio rem. Perspiciatis voluptatibus maiores necessitatibus quidem, sapiente, odio neque optio veniam ad blanditiis, culpa dicta et beatae ut earum explicabo. Deleniti, obcaecati quam?
            Facere, ullam nam accusantium suscipit distinctio voluptates illum deserunt ducimus architecto omnis unde et fuga inventore, veritatis similique aut, placeat accusamus corporis nisi? Quasi distinctio pariatur officiis ratione odit. Quis.
            Repudiandae inventore illo atque aliquam, asperiores nesciunt odio maiores deleniti vel porro animi ipsa eveniet nostrum temporibus modi saepe itaque, numquam similique ut at? In explicabo quod inventore adipisci rerum?
            Quidem, sapiente quis. Fuga suscipit in amet. Eligendi mollitia sapiente, dolor voluptatum nam expedita ab quia nemo, alias, hic assumenda ullam provident facere nihil exercitationem aspernatur neque nisi doloremque ipsum.
            Quo alias voluptatibus odit aliquam itaque, voluptate possimus nam et, soluta quas ex perferendis, sed vel mollitia! Eius nesciunt libero quo quia nobis illo esse nisi animi. Quisquam, officiis eaque!</p>
        </div>
    </div>
</div>