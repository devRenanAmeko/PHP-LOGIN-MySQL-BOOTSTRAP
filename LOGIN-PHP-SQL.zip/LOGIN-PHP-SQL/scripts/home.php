<?php 
require_once __DIR__ . '/../inc/navbar.php';
?>

<div class="container nt-5">
    <div class="row">
        <div class="col">
            <hr>
            <h4>Home</h4>
            <p class="mt-5">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non sit rem, quia voluptates modi, eligendi eius vel dolorum repudiandae maiores cumque expedita corrupti doloribus numquam necessitatibus et nulla eaque. Iste?
            Beatae cum numquam veniam unde laboriosam fugiat nihil, quisquam aut corrupti architecto! Delectus reiciendis similique, quidem eveniet, aliquam laudantium magnam quia laborum, earum eum amet modi iure repudiandae consectetur assumenda?
            Praesentium autem, commodi maxime beatae amet sunt quos at, doloribus maiores totam, possimus mollitia ratione tenetur expedita. Numquam dolorem ipsa aliquid tempora, tempore pariatur ut voluptatum a. Accusamus, nostrum quibusdam.
            Reprehenderit omnis corporis maiores nulla quaerat. Aliquam neque veritatis voluptatem sint, illo saepe quam, et eius fugit ipsum ab consequuntur voluptates. Eligendi maiores blanditiis at numquam praesentium porro modi magni.
            Optio cum ab autem, non delectus deleniti dicta expedita rem enim veritatis? Repellat, eum similique. Eveniet, consequuntur consequatur harum aperiam, non sed impedit modi atque voluptatibus ducimus cum, optio porro.</p>
        </div>
    </div>
</div>