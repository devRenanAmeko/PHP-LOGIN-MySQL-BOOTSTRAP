<?php

//temporario apenas para gerar a hash do pass
echo password_hash('abc123',PASSWORD_DEFAULT);