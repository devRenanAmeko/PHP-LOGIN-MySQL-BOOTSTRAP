<?php

//configuracoes do banco de dados
define('DB_HOST',       'localhost');
define('DB_NAME',       'php_login');
define('DB_USER',       'user_php_login');
define('DB_PASS',       'adm123');