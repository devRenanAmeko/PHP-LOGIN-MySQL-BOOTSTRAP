<?php

return [
    '404',
    'home',
    'login',
    'login_submit',
    'logout',

    'page1',
    'page2',
    'page3'
];